import java.util.ArrayList;

public class Question {

    String question;
    ArrayList<String> options;
    char answer;

    Question () {
        question = "";
        options = new ArrayList<>();
        answer = 0;
    }

}
